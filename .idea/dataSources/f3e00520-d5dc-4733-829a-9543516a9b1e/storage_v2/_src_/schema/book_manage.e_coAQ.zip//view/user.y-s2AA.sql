create definer = root@localhost view user as
select `book_manage`.`borrow_record`.`user_id` AS `用户ID`, count(`book_manage`.`borrow_record`.`user_id`) AS `借阅次数`
from `book_manage`.`borrow_record`
group by `book_manage`.`borrow_record`.`user_id`
order by `借阅次数` desc;

