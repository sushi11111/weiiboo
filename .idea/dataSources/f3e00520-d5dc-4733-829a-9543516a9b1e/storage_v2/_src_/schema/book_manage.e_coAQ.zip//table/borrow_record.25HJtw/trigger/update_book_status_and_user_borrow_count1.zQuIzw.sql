create definer = root@localhost trigger update_book_status_and_user_borrow_count1
    after update
    on borrow_record
    for each row
BEGIN
    IF NEW.real_return_date IS NOT NULL AND OLD.real_return_date IS NULL THEN
        UPDATE books SET status = '闲置' WHERE book_id = OLD.book_id;
        UPDATE users SET count = count + 1 WHERE id = OLD.user_id;
        UPDATE overdue_record SET status='已归还' WHERE borrow_id = OLD.borrow_id;
    END IF;

END;

