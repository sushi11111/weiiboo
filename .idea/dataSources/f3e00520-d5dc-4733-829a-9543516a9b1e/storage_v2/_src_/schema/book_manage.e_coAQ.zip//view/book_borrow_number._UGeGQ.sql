create definer = root@localhost view book_borrow_number as
select `book_manage`.`books`.`book_id`                  AS `id`,
       count(`book_manage`.`borrow_record`.`borrow_id`) AS `borrow_num`,
       `book_manage`.`books`.`title`                    AS `title`
from (`book_manage`.`books` left join `book_manage`.`borrow_record`
      on ((`book_manage`.`borrow_record`.`book_id` = `book_manage`.`books`.`book_id`)))
group by `book_manage`.`books`.`book_id`
order by `borrow_num` desc;

