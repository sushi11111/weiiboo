create definer = root@localhost trigger check_book_status_and_user_borrow_count
    before insert
    on borrow_record
    for each row
BEGIN
    DECLARE book_status VARCHAR(20);
    DECLARE user_borrow_count INT;
    SELECT status INTO book_status FROM books WHERE book_id = NEW.book_id;
    SELECT count INTO user_borrow_count FROM users WHERE id = NEW.user_id;
    IF book_status <> '闲置' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Book is not available for borrowing';
    END IF;
    IF user_borrow_count <=0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'User has reached the maximum borrowing limit';
    END IF;
END;

