create definer = root@localhost view userfine as
select `book_manage`.`user`.`用户ID`      AS `id`,
       `book_manage`.`user`.`借阅次数`    AS `borrow_num`,
       `book_manage`.`fine_user`.`罚款数` AS `fine_num`
from (`book_manage`.`user` left join `book_manage`.`fine_user`
      on ((`book_manage`.`fine_user`.`用户ID` = `book_manage`.`user`.`用户ID`)))
order by `book_manage`.`user`.`借阅次数`;

