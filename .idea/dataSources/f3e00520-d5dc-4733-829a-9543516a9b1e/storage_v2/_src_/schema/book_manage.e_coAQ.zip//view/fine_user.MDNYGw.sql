create definer = root@localhost view fine_user as
select `book_manage`.`borrow_record`.`user_id` AS `用户ID`, sum(`book_manage`.`fines`.`max_amount`) AS `罚款数`
from (`book_manage`.`borrow_record` join `book_manage`.`fines`
      on ((`book_manage`.`fines`.`borrow_id` = `book_manage`.`borrow_record`.`borrow_id`)))
group by `book_manage`.`borrow_record`.`user_id`
order by `book_manage`.`borrow_record`.`user_id` desc;

