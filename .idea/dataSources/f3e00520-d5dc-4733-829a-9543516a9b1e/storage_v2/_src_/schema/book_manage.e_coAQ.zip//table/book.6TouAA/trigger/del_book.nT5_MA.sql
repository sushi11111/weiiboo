create definer = root@localhost trigger del_book
    before delete
    on book
    for each row
    DELETE FROM borrow WHERE bid=old.bid;

