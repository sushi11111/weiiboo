create definer = root@localhost trigger del
    before delete
    on student
    for each row
    DELETE FROM borrow WHERE sid = old.sid;

