create definer = root@localhost trigger update_book_status_and_user_borrow_count
    after insert
    on borrow_record
    for each row
BEGIN
    UPDATE books SET status = '借阅中' WHERE book_id = NEW.book_id;
    UPDATE users SET count = count-1 WHERE id = NEW.user_id;
END;

