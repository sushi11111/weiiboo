create definer = root@localhost view userfine as
select `library_db`.`user`.`用户ID`      AS `id`,
       `library_db`.`user`.`借阅次数`    AS `borrow_num`,
       `library_db`.`fine_user`.`罚款数` AS `fine_num`
from (`library_db`.`user` left join `library_db`.`fine_user`
      on ((`library_db`.`fine_user`.`用户ID` = `library_db`.`user`.`用户ID`)))
order by `library_db`.`user`.`借阅次数`;

