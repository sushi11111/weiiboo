create definer = root@localhost view fine_user as
select `library_db`.`borrow_record`.`user_id` AS `用户ID`, sum(`library_db`.`fines`.`max_amount`) AS `罚款数`
from (`library_db`.`borrow_record` join `library_db`.`fines`
      on ((`library_db`.`fines`.`borrow_id` = `library_db`.`borrow_record`.`borrow_id`)))
group by `library_db`.`borrow_record`.`user_id`
order by `library_db`.`borrow_record`.`user_id` desc;

