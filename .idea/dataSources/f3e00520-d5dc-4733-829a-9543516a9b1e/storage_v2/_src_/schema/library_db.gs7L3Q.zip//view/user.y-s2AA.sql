create definer = root@localhost view user as
select `library_db`.`borrow_record`.`user_id` AS `用户ID`, count(`library_db`.`borrow_record`.`user_id`) AS `借阅次数`
from `library_db`.`borrow_record`
group by `library_db`.`borrow_record`.`user_id`
order by `借阅次数` desc;

