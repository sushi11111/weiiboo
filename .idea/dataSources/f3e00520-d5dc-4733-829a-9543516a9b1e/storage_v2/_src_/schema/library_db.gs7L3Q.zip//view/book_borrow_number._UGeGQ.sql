create definer = root@localhost view book_borrow_number as
select `library_db`.`books`.`book_id`                  AS `id`,
       count(`library_db`.`borrow_record`.`borrow_id`) AS `borrow_num`,
       `library_db`.`books`.`title`                    AS `title`
from (`library_db`.`books` left join `library_db`.`borrow_record`
      on ((`library_db`.`borrow_record`.`book_id` = `library_db`.`books`.`book_id`)))
group by `library_db`.`books`.`book_id`
order by `borrow_num` desc;

