create definer = root@localhost trigger prevent_book_deletion
    before delete
    on books
    for each row
BEGIN
    IF OLD.status = '借阅中' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '图书正在被借阅，无法删除。';
    END IF;
END;

